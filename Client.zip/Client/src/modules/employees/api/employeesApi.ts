import { httpGet, httpPost, httpPut } from '@/shared/api/axiosClient';
import type { PagedResult } from '@/shared/types/api';
import type {
  CreateEmployeeRequest,
  Employee,
  EmployeeFilter,
  UpdateEmployeeRequest,
} from '@/modules/employees/types/employees';

/** Danh sách nhân viên kèm vị trí đang giữ; keyword tìm theo mã, họ tên, email, số điện thoại. */
export const getEmployees = (filter: EmployeeFilter) => httpGet<PagedResult<Employee>>('/employees', filter);

export const getEmployeeById = (id: number) => httpGet<Employee>(`/employees/${id}`);

/** Nhân viên mới luôn ở trạng thái ACTIVE; có initialAssignment thì bổ nhiệm luôn vị trí ban đầu. */
export const createEmployee = (request: CreateEmployeeRequest) => httpPost<Employee>('/employees', request);

export const updateEmployee = (id: number, request: UpdateEmployeeRequest) =>
  httpPut<Employee>(`/employees/${id}`, request);

/** Ảnh lưu ở thư mục upload của Server, trả về nhân viên với avatarUrl mới. */
export const uploadEmployeeAvatar = (id: number, file: File) => {
  const body = new FormData();
  body.append('file', file);
  return httpPost<Employee>(`/employees/${id}/avatar`, body);
};

/** Người đang đăng nhập tự đổi ảnh đại diện (không cần quyền sửa nhân viên). */
export const uploadMyAvatar = (file: File) => {
  const body = new FormData();
  body.append('file', file);
  return httpPost<Employee>('/employees/me/avatar', body);
};
