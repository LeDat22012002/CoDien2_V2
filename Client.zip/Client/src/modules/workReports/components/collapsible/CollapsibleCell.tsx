import type { TdHTMLAttributes } from "react";
import "./collapsibleRows.css";

/**
 * Ô thân bảng AntD có hiệu ứng thu/mở: bọc nội dung trong lưới 1fr ↔ 0fr để co chiều cao mượt.
 * Dòng thu gọn được đánh dấu bằng collapsibleRowProps (data-collapsed trên <tr>); CSS lo phần còn lại.
 */
export const CollapsibleCell = ({
  className,
  children,
  ...rest
}: TdHTMLAttributes<HTMLTableCellElement>) => (
  <td
    {...rest}
    className={["collapsible-cell", className].filter(Boolean).join(" ")}
  >
    <div className="collapsible-cell__body">
      <div className="collapsible-cell__clip">{children}</div>
    </div>
  </td>
);
