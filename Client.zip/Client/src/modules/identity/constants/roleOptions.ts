/** Tên hiển thị nhóm quyền theo Permission.Module ở Server; module mới chưa khai báo thì hiện nguyên mã. */
export const PERMISSION_MODULE_LABELS: Record<string, string> = {
  dashboard: 'Tổng quan',
  employees: 'Nhân viên',
  users: 'Tài khoản',
  roles: 'Vai trò và phân quyền',
  pages: 'Trang và menu',
  organization: 'Tổ chức',
  documents: 'Văn bản',
  equipments: 'Thiết bị',
  incidents: 'Sự cố',
  'work-reports': 'Báo cáo tuần',
  'audit-logs': 'Nhật ký hệ thống',
};

export const getPermissionModuleLabel = (module: string) => PERMISSION_MODULE_LABELS[module] ?? module;

/** Trang gán quyền cho vai trò (?role=id). */
export const PERMISSION_ASSIGNMENT_PATH = '/admin/permissions';

/** Mã vai trò: khớp RoleRequestValidator ở Server. */
export const ROLE_CODE_PATTERN = /^[A-Z][A-Z0-9_]{1,49}$/;

/** Bỏ dấu, chữ thường để tìm kiếm tiếng Việt. */
export const normalizeSearchText = (value: string) =>
  value
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'D')
    .toLowerCase()
    .trim();
