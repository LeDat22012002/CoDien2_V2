# CLAUDE.md — Server (.NET 8 Web API + SQL Server)

Đọc kèm `../CLAUDE.md`.

## Cấu trúc (Modular, 1 project)

```
server/
├── Server.sln, Server.csproj
├── appsettings*.json, Properties/launchSettings.json
├── Api/                  # Host: Program.cs, Middlewares/, Extensions/ (AddData, AddModules, AddApiControllers)
├── Gateway/              # Điểm vào duy nhất: JWT, CORS, rate limit, fallback policy bắt buộc đăng nhập
├── Modules/
│   └── <ModuleName>/
│       ├── Controllers/        # <Entity>sController.cs
│       ├── DTOs/               # <Entity>Dto.cs — 1 file/entity chứa mọi DTO của entity đó
│       ├── Entities/           # <Entity>.cs — 1 file/entity chứa entity + hằng số giá trị hợp lệ của nó
│       ├── Repositories/       # <Entity>Repository.cs
│       │   └── Interfaces/     # I<Entity>Repository.cs
│       ├── Services/           # <Entity>Service.cs
│       │   └── Interfaces/     # I<Entity>Service.cs
│       ├── Validators/
│       └── <ModuleName>Module.cs   # Add<ModuleName>Module(): đăng ký DI của module
├── Shared/               # Entities/ (BaseEntity), Exceptions/, Models/ (ApiResponse, PagedRequest, PagedResult), Services/ (CurrentUserService)
├── Data/                 # AppDbContext, IUnitOfWork/UnitOfWork, Configurations/ (Fluent API), Migrations/
└── Tests/                # Project test riêng (chưa tạo), không biên dịch chung
```

- Tên module (thư mục + namespace) dùng **số nhiều** (`Modules/Employees`) để không trùng tên class entity (`Employee`), tránh lỗi C# hiểu nhầm namespace. Module mẫu tham khảo: `Employees`.
- Namespace theo thư mục: `Server.Modules.<ModuleName>.<Folder>`, `Server.Shared.*`, `Server.Data`.
- Thêm module mới: tạo `Modules/<ModuleName>/...` và `<ModuleName>Module.cs`, rồi gọi `services.Add<ModuleName>Module()` trong `Api/Extensions/ServiceCollectionExtensions.AddModules()`.
- Module không gọi thẳng Repository của module khác; nếu cần dữ liệu thì gọi qua Service.

## Đặt tên

- File trùng tên class. **Ngoại lệ:** `DTOs/<Entity>Dto.cs` gom mọi DTO của entity (thứ tự: Response `<Entity>Dto` → `<Entity>RequestBase` → `Create/Update<Entity>Request` → `<Entity>FilterRequest`); `Entities/<Entity>.cs` gom entity và các static class hằng số giá trị (Status, loại…). Mỗi entity một file, không gom nhiều entity vào một file.
- Namespace theo thư mục, kể cả `...Services.Interfaces`, `...Repositories.Interfaces`.
- Class, method, property dùng PascalCase; biến và tham số dùng camelCase; field private dùng `_camelCase`.
- Method bất đồng bộ có hậu tố `Async`. Interface có tiền tố `I`.
- Đặt tên theo entity (một module có thể chứa nhiều entity): Controller `<Entity>sController`, Service `I<Entity>Service` / `<Entity>Service`, Repository `I<Entity>Repository` / `<Entity>Repository`.
- DTO: `<Entity>Dto`, `Create<Entity>Request`, `Update<Entity>Request`, `<Entity>FilterRequest` (kế thừa `PagedRequest`).

## Cơ sở dữ liệu

- Bảng: PascalCase, **số ít** (đồng bộ với DB có sẵn: `Employee`, `OrgUnit`, `User`, `Role`…), luôn khai báo schema `dbo`. Cột: PascalCase. Khóa chính `Id`, khóa ngoại `<Entity>Id`.
- Bảng `User` trùng từ khóa SQL: viết SQL tay phải dùng `[dbo].[User]`.
- Cột unique trên bảng có xóa mềm dùng index có điều kiện `.HasFilter("[IsDeleted] = 0")`. Bảng nối tới entity có xóa mềm phải khai báo query filter tương ứng (vd `UserRole`: `!x.User.IsDeleted && !x.Role.IsDeleted`).
- Mọi bảng nghiệp vụ kế thừa `BaseEntity` gồm: `CreatedAt`, `CreatedBy`, `UpdatedAt`, `UpdatedBy`, `IsDeleted`. `AppDbContext` tự điền audit và tự đổi Remove thành xóa mềm.
- Xóa mềm bằng Global Query Filter (tự áp cho mọi entity kế thừa `BaseEntity`). Chuỗi dùng `nvarchar` có `MaxLength`; số lượng và tiền dùng `decimal` (mặc định precision 18,4).
- Cấu hình bảng bằng Fluent API trong `Data/Configurations/<Entity>Configuration.cs`, không dùng Data Annotation. Repository dùng `dbContext.Set<T>()`, không cần thêm DbSet vào AppDbContext.
- **Bảng có sẵn trong DB** (database `NM_CD2`, không do EF tạo, ví dụ `dbo.Employee`): giữ nguyên tên bảng và cột, cấu hình `ToTable("<Tên>", "dbo", t => t.ExcludeFromMigrations())`. Bảng nào thiếu cột audit thì entity không kế thừa `BaseEntity` và xóa là xóa cứng.
- Migration (chạy tại thư mục `server/`):
  `dotnet ef migrations add <Name> -o Data/Migrations`
  `dotnet ef database update`

## Quy tắc code

- Controller mỏng: chỉ gọi Service và trả `ApiResponse<T>`. Logic nghiệp vụ nằm ở Service, truy vấn nằm ở Repository.
- Không trả Entity ra API, luôn map sang DTO.
- Repository không gọi SaveChanges; Service gọi `IUnitOfWork.SaveChangesAsync`.
- Dùng async/await kèm `CancellationToken`. Query chỉ đọc dùng `AsNoTracking()`.
- Ghi nhiều bảng thì bọc trong `IUnitOfWork.ExecuteInTransactionAsync`. Gọi lồng (service này gọi service khác cũng dùng transaction) thì lần trong dùng chung transaction ngoài, chỉ SaveChanges; lỗi ở đâu cũng rollback cả.
- Lỗi xử lý tập trung tại middleware; Service ném exception trong `Shared/Exceptions` (`NotFoundException` → 404, `ForbiddenException` → 403, `UnauthorizedException` → 401, còn lại → 400).
- Validate request trong `Modules/<M>/Validators` (static class, thông báo tiếng Việt, key lỗi camelCase), ném `ValidationException`.
- API công khai: gắn `[AllowAnonymous]` trên từng action GET; còn lại mặc định bắt buộc đăng nhập.
- File tải lên (ảnh đại diện…): qua `IFileStorageService`, lưu ngoài mã nguồn tại `FileStorage:RootPath` (mặc định `D:/Uploads`), phục vụ tĩnh ở `/api/uploads/...`; DB chỉ lưu URL. Ảnh đại diện thuộc nhân viên: `POST /api/employees/{id}/avatar` (`employees.update`); tự đổi ảnh của mình: `POST /api/employees/me/avatar` (chỉ cần đăng nhập); `/api/auth/me` trả `avatarUrl` từ Employee.

## Phân quyền (module Identity)

- RBAC: User (gắn 1 Employee, đăng nhập bằng EmpCode) → nhiều Role → nhiều Permission. Trang (Page) hiển thị khi user có permission xem của trang. Role `SUPER_ADMIN` có toàn quyền.
- Mã quyền dạng `<module>.<hành động>` khai báo trong `Shared/Constants/PermissionCodes.cs`.
- **Permission do code định nghĩa** (vì API phải kiểm tra đúng mã đó): thêm chức năng cần quyền mới → thêm mã vào `PermissionCodes` và `IdentitySeedData.Permissions`; khi khởi động `IdentitySeeder` chỉ **thêm mã mới**, không ghi đè, không xóa. Admin trên FE chỉ xem, sửa tên hiển thị và gán quyền cho role.
- **Page quản lý từ FE** (CRUD qua API): `IdentitySeedData.Pages` chỉ là bộ trang mặc định, seed **riêng từng Area, một lần khi Area đó chưa có trang nào** (Area đã có trang thì seed không đụng tới; thêm trang vào Area đã có thì tạo trên FE). `Path` phải khớp route có thật ở Client.
- `Page.Area`: `ADMIN` = menu Sider trang quản trị (`/api/auth/me` → `menu`); `MEMBER` = menu Sider trang cá nhân `/member/...` (`/api/auth/me` → `memberMenu`, trang không gắn quyền = ai đăng nhập cũng thấy); `routes` gồm trang của cả ADMIN và MEMBER; `PUBLIC` = menu header trang công khai (`GET /api/pages/public-menu`, `[AllowAnonymous]`). Trang PUBLIC chỉ là liên kết điều hướng, **không gắn quyền**; quyền vào route vẫn theo trang ADMIN cùng path (Path chỉ cần duy nhất trong cùng Area). Trang con cùng Area với trang cha.
- `Page.ExternalUrl`: liên kết ngoài http/https (mở tab mới), không nhập cùng `Path`.
- Admin tổng đầu tiên lấy từ User Secrets `Identity:SuperAdmin:EmpCode` / `Identity:SuperAdmin:InitialPassword`, chỉ tạo khi chưa có SUPER_ADMIN nào.
- **Gắn quyền cho API**: `[HasPermission(PermissionCodes.X.Y)]` trên action (hoặc controller). Truyền nhiều mã = chỉ cần có 1 trong số đó. Không gắn gì = chỉ cần đăng nhập; `[AllowAnonymous]` = công khai.
- Trong service, lấy người đang gọi qua `ICurrentUserService` (`UserId`, `UserName` = EmpCode); kiểm tra quyền/leo thang qua `IPermissionService` (`EnsureCanGrantPermissionsAsync`, `EnsureCanAssignRolesAsync`).
- Token: access token 15 phút trong JSON (claims `sub`, `emp_code`, `full_name`, `stamp`, **không chứa quyền**); refresh token trong cookie HttpOnly `refresh_token` (Path `/api/auth`): tick "Nhớ mật khẩu" (`LoginRequest.IsRemembered`) → `RefreshToken.IsPersistent`, hạn `RememberMeDays` (30, tính lại mỗi lần refresh), cookie có Expires; không tick → cookie phiên, hạn `RefreshTokenDays` (7); xoay vòng và đổi mật khẩu giữ nguyên chế độ, DB chỉ lưu SHA-256, xoay vòng mỗi lần refresh, dùng lại token cũ → thu hồi mọi phiên.
- Quyền và trạng thái user được cache (`IMemoryCache`, 10 phút). Đổi role/quyền/khóa/mật khẩu phải gọi `IPermissionService.InvalidateUser` hoặc `InvalidateAll` để có hiệu lực ngay; đổi mật khẩu/ngừng tài khoản gọi `user.RenewSecurityStamp()` để vô hiệu access token cũ.
- Chống leo thang: không tự sửa role/trạng thái của mình; phải còn ≥ 1 SUPER_ADMIN hoạt động; người không phải SUPER_ADMIN không đụng tới role/tài khoản SUPER_ADMIN và chỉ cấp được quyền mình đang có.
- Tài khoản cũ chuyển 1 lần từ `TEST.dbo.Tbl_TaiKhoan` bằng `Data/Scripts/MigrateUsersFromTest.sql` (vai trò `NGUOI_DUNG`). Mật khẩu cũ giữ dạng `MD5:<hex>`; `UserPasswordHasher` nhận hash này và tự đổi sang PBKDF2 ở lần đăng nhập đầu tiên.
- Viết SQL tay bằng `sqlcmd` phải thêm cờ `-I` (bật QUOTED_IDENTIFIER) vì bảng có filtered index.

## Cơ cấu tổ chức (module Organization)

- Bảng có sẵn (ExcludeFromMigrations): `OrgUnit`, `OrgUnitType`, `OrgUnitTypeParent`, `PositionLevel`, `Discipline`, `EmployeeAssignment`. View chỉ đọc (`ToView` + `HasNoKey`): `vOrgUnit` (cấp trưởng/phó thực tế), `vUnitMember` (UnitRole HEAD/DEPUTY/MEMBER), `vAssignmentHistory`. DB không có FK giữa các bảng này.
- Trưởng của đơn vị = `OrgUnit.HeadLevelCode ?? OrgUnitType.HeadLevelCode`; `OrgUnitType.SingleHead = false` cho phép nhiều trưởng (Nhóm theo ca). Cha hợp lệ theo `OrgUnitTypeParent`. Tổ (GROUP) không là node riêng trên sơ đồ mà gộp vào khối "Tổ trưởng" của đơn vị cha.
- Đổi chức vụ (`AssignmentService.ChangeAsync`, thay cho `usp_ChangeAssignment` cũ): kết thúc mọi vị trí chính đang giữ vào ngày trước ngày hiệu lực rồi tạo vị trí chính mới; chặn trưởng chính thức thứ 2 ở đơn vị SingleHead, chặn Kỹ sư thứ 2 ở Tổ, ngày hiệu lực phải sau ngày bắt đầu vị trí hiện tại.
- Tạo nhân viên **bắt buộc** có vị trí ban đầu (đơn vị của vị trí = nhân viên thuộc xưởng nào), nên cần thêm quyền `assignments.manage`.
- Ẩn khỏi sơ đồ theo từng người: bảng EF `OrgChartHiddenEmployee` (có dòng = ẩn, hiện lại = xóa mềm). Người bị ẩn vẫn giữ vị trí và thuộc đơn vị; chỉ `OrgChartRepository` (sơ đồ + thành viên đơn vị) bỏ qua họ. Đặt qua `IOrgChartService.SetHiddenAsync` (form nhân viên, cần `assignments.manage`).
- Nhân viên chuyển INACTIVE → `IAssignmentService.EndAllActiveAsync` kết thúc mọi vị trí (Employees gọi qua Service, lưu chung 1 lần SaveChanges).
- Xóa đơn vị = `IsActive = false`; chặn khi còn đơn vị con hoặc còn người giữ vị trí. GD luôn hàng 1, PGD luôn hàng 2 trên sơ đồ.
- Báo cáo sự cố: `GET /api/incidents/my-scope` (cần đăng nhập) trả quyền quản lý / phân tích và xưởng (đơn vị cấp 1 loại WORKSHOP) của người đang đăng nhập, để FE ẩn/hiện nút từng dòng; quyền thật vẫn kiểm tra trong `IncidentService`.
- Trang Sơ đồ tổ chức là trang công khai: `GET /api/org-chart` và `GET /api/org-chart/units/{id}/members` gắn `[AllowAnonymous]` (gồm cả email, SĐT nhân viên); `lookups` vẫn cần `org-chart.view`.
- Secret lấy từ User Secrets (máy dev) hoặc `appsettings.Production.json` / biến môi trường (IIS). Connection string và `Jwt:SecretKey` không ghi vào `appsettings.json`. Hướng dẫn cấu hình: `README.md` gốc.

## Cấp số văn bản (module Documents)

- Bảng do EF tạo (migration `AddDocuments`): `DocumentTemplate` (biểu mẫu), `IssuedDocument` (sổ văn bản đã cấp). Dữ liệu cũ chuyển 1 lần từ `TEST.dbo.BieuMau` / `TEST.dbo.SoVanBanDaCap` bằng `Data/Scripts/MigrateDocumentsFromTest.sql` (giữ Id; trạng thái `chua/co/huy` → `PENDING/PUBLISHED/CANCELLED`).
- Đánh số **theo từng biểu mẫu, theo năm** (`DateTime.Now.Year`), STT = max + 1; `StartNumber` giữ lại nhưng không dùng. 5 API cấp số riêng (giữ nguyên công thức hệ thống cũ):
  - Thường `POST /api/issued-documents`: `{STT:D2}/{Năm}/{Đuôi số}`
  - Nghiệm thu `acceptance-records`: `{Lần:D2}/{Số HĐ}/{Tên viết tắt}`, lần = số văn bản đã có cùng đuôi trên mọi biểu mẫu + 1 (Seq = Year = 0)
  - XNKT `technical-confirmations`: `XNKT.{STT:D2}-{Năm}/{PR}/{Nhà thầu}`
  - PAKT `technical-plans`: `{STT:D2}/{Năm}/PAKT-NM.CĐ2-{Nhà thầu}`
  - Thanh toán theo HĐ `contract-payments`: `{STT:D2}/{Số HĐ}/{Năm HĐ}/{Đuôi số}`; HĐ mới bắt đầu 01, HĐ cũ tăng từ số mới nhất của HĐ đó.
- **Chống trùng số:** đọc số lớn nhất bằng `WITH (UPDLOCK, HOLDLOCK)` trong `ExecuteInTransactionAsync`. Không có unique index vì dữ liệu cũ đang có số trùng — không đổi công thức đánh số khi chưa hỏi.
- Người lấy số lấy từ tài khoản đăng nhập; đơn vị = đơn vị cấp 1 (dưới Nhà máy) trên sơ đồ tổ chức (`IAssignmentService.GetTopLevelUnitNameAsync`). Chưa được gán đơn vị → không lấy được số. `IssuedAt` lưu giờ địa phương.
- Sửa: người lấy số hoặc có `documents.manage`. Xóa (mềm): chỉ số mới nhất của biểu mẫu trong năm. Biểu mẫu đã dùng không xóa được.
- Lọc sổ (`GET /api/issued-documents`): `keyword` (họ tên, mã NV, số hiệu, trích yếu), `publishStatus`, biểu mẫu, ngày ban hành. `GET export` dùng cùng bộ lọc (bỏ phân trang) — FE quản trị xuất đúng những gì đang lọc.

## Thiết bị (module Equipments)

- Bảng do EF tạo `Equipment` (migration `AddEquipmentsAndIncidents`), `Code` unique có điều kiện. Dữ liệu cũ `TEST.dbo.Equipment` có mã lặp (bản trùng giống hệt) → script giữ Id nhỏ nhất mỗi mã.
- Xem (`GET /api/equipments`, `/options`): chỉ cần đăng nhập. Thêm/sửa/xóa/import: `equipments.manage`. Import bỏ qua mã đã có hoặc lặp trong file; `import-default` đọc 4 sheet "THAM CHIẾU EQ - …" cố định.
- Xóa (mềm) bị chặn khi đã có báo cáo sự cố — kiểm tra qua `IIncidentLookupService` (tách riêng để tránh vòng DI với `IncidentService`).

## Nhật ký hệ thống (module AuditLogs)

- Bảng EF `AuditLog` (không kế thừa `BaseEntity`, xóa cứng). `Type`: `LOGIN` | `PAGE_VIEW` | `ACTION`. `CreatedAt` giờ địa phương.
- `Api/Middlewares/AuditLogMiddleware` (đăng ký **trước** `ExceptionHandlingMiddleware` để thấy kết quả cuối): ghi mọi POST/PUT/PATCH/DELETE `/api/...` của người đã đăng nhập và `POST /api/auth/login` (cả thành công / thất bại). Bỏ qua `/api/auth/refresh` và request chưa đăng nhập. Lưu body JSON / form (che trường chứa `password|token|secret`, file chỉ ghi tên + dung lượng, tối đa 4000 ký tự), mã HTTP, `message` của response, `Controller.Action`, IP, trình duyệt, thời gian xử lý.
- Truy cập trang: Client gọi `POST /api/audit-logs/page-views` khi người đã đăng nhập đổi pathname (`layouts/hooks/usePageViewTracking`). Xem: `GET /api/audit-logs` (`audit-logs.view`).
- Ghi DB qua hàng đợi `IAuditLogQueue` (Channel, singleton) + `AuditLogWriterService` ghi theo lô bằng scope riêng (không lẫn DbContext của request). `AuditLogCleanupService` mỗi 24h xóa log cũ hơn `AuditLog:RetentionDays` (mặc định 30).
- Thêm API ghi mới không cần làm gì thêm; trường nhạy cảm mới phải có tên chứa password/token/secret, nếu không thì bổ sung `SensitiveKeywords` trong middleware.

## Báo cáo sự cố (module Incidents)

- Bảng do EF tạo `Incident`. Dữ liệu cũ chuyển 1 lần bằng `Data/Scripts/MigrateIncidentsFromTest.sql` (chạy sqlcmd với `-f 65001`): xưởng cũ `Tbl_Xuong` → OrgUnit cấp 1 qua `#WorkshopMap`; người nhập `Tbl_TaiKhoan.TenTaiKhoan` = `Employee.EmpCode`. TEST và NM_CD2 khác collation → so sánh chuỗi phải `COLLATE DATABASE_DEFAULT`.
- Xưởng = đơn vị cấp 1 (`IOrgUnitService.GetTopLevelUnitsAsync`); xưởng của người dùng: `IAssignmentService.GetTopLevelUnitAsync`.
- Mã/tên thiết bị lưu dạng bản chụp; tạo/sửa qua API phải có mã trong danh mục (chỉ kiểm tra khi mã đổi), import Excel thì không bắt buộc.
- Người phân tích (`Analyst*`, `AnalyzedAt`) ghi mỗi lần lưu `/analysis`; người bổ sung (`Supplementer*`, `SupplementedAt`) ghi mỗi lần lưu `/supplement`, khi tạo có điền số order/link, hoặc khi sửa đầy đủ làm đổi số order/link. Dữ liệu cũ để null.
- `ReportedAt` (giờ địa phương) + người nhập lấy theo tài khoản khi tạo; dữ liệu import để null → không vào dashboard, không cảnh báo quá hạn.
- Quyền: GET danh sách/chi tiết/dashboard/thiết bị lặp lại công khai; tạo: `incidents.create` hoặc `incidents.manage`; tiến độ (`/progress`): người nhập (báo cáo của mình), `incidents.update-progress` cùng xưởng (quản đốc, đội trưởng) hoặc manage; phân tích (`/analysis`): `incidents.analyze` cùng xưởng hoặc manage; bổ sung (`/supplement`): người nhập, analyze cùng xưởng hoặc manage; sửa đầy đủ/xóa/import: chỉ `incidents.manage`.
- Quy tắc (`IncidentRules`): quá hạn phân tích > 7 ngày thiếu nguyên nhân/nguyên nhân gốc/hành động; quá hạn bổ sung (có AHSX) > 3 ngày thiếu số order/link; `IncidentReportLink` (link báo cáo sự cố) chỉ nhập qua `/supplement`, bắt buộc khi AHSX, cảnh báo (FE) khi AHSX > 5 ngày chưa có; mốc so sánh `now − (N + 1)` ngày; thiết bị lặp lại > 3 lần/năm. Thứ tự mốc: nhận tin ≤ bắt đầu sửa ≤ sửa xong ≤ bàn giao.
- Dashboard "thời gian sự cố" = tổng (sửa xong − bắt đầu sửa), tính trực tiếp bằng SQL trên bảng `Incident` (không có bảng tổng hợp riêng), chỉ báo cáo có `ReportedAt` và đủ 2 mốc; theo xưởng (toàn nhà máy), loại sự cố, kíp; trả kèm số báo cáo thiếu mốc.
